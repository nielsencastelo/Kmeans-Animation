% Fun��o que verifica quantas classes existe no vetor
% Data: 20/05/2013
% Autor: Nielsen C. Damasceno
% Entrada: classes
% Sa�da :  num - n�mero de classes
            
function num = ver_classes(classes)
    num = 0;    
    for i = 1 : length(classes)
        diferente = true;
        for j = i - 1 : -1 :  1 % Decremento o vetor
            if classes(j) == classes(i)
                diferente = false;
            end
        end
        if(diferente)
            num = num + 1;
        end
    end
    
end